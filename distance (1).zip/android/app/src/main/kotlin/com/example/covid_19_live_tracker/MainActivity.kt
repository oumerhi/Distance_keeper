package com.example.covid_19_live_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
