class TimeSeriesCases {
  final DateTime time;
  final int cases;

  TimeSeriesCases(this.time, this.cases);
}