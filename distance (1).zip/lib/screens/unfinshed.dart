import 'package:flutter/material.dart';

class UnfinishedProject extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.grey[500],
          title: Text("Unifinished Project"),
        ),
        body: Center(child: Text("this is unifinished project due too shortage of time")),
      ),
    );
  }
}
